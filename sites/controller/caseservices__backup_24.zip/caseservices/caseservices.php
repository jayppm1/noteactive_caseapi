<?php
header ( 'Access-Control-Allow-Origin:' . $_SERVER ['HTTP_ORIGIN'] );
header ( 'Access-Control-Allow-Methods: POST, GET, OPTIONS' );
header ( 'Access-Control-Max-Age: 1000' );
header ( 'Access-Control-Allow-Headers: Content-Type' );
header ( 'Content-type: application/json;' );
header ( 'Content-Type: text/html; charset=utf-8' );
class Controllercaseservicescaseservices extends Controller {
	
	public function generate_uuid() {
		return sprintf( '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
			mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ),
			mt_rand( 0, 0xffff ),
			mt_rand( 0, 0x0C2f ) | 0x4000,
			mt_rand( 0, 0x3fff ) | 0x8000,
			mt_rand( 0, 0x2Aff ), mt_rand( 0, 0xffD3 ), mt_rand( 0, 0xff4B )
		);

	}
	
	public function jsonuserLogin() {
		
		try {
			
			$this->load->model ( 'activity/activity' );
			$this->model_activity_activity->addActivitySave ( 'jsonuserLogin', $this->request->post, 'request' );
				

			$this->data ['facilitiess'] = array ();
			
			//$data = json_decode(file_get_contents("php://input"));
			
			//$json = array ();
			//$jsonData2 = stripslashes ( html_entity_decode ( $this->request->post ) );
			//$username = json_decode ( $this->request->post , true );
			//$jsonData2 = stripslashes ( html_entity_decode ( $this->request->post['password'] ) );
			//$password = json_decode ( $jsonData2, true );
			
			//$data->username
			//$data->password; 
			
			// $username = $data->username; 				 
			 //$password = $data->password; 

				$username = $this->request->post['username']; 				 
				$password = $this->request->post['password']; 			 

			if ($username == null && $username == "") {
				
				$json ['warning'] = 'Please enter username';
				$facilitiessee = array ();
				$facilitiessee [] = array (
						'warning' => $json ['warning'] 
				);
				$error = false;
				
				$value = array (
						'results' => $facilitiessee,
						'status' => false 
				);
				
				return $this->response->setOutput ( json_encode ( $value ) );
			}
			
			if ($password == null && $password == "") {
				
				$json ['warning'] = 'Please enter password';
				$facilitiessee = array ();
				$facilitiessee [] = array (
						'warning' => $json ['warning'] 
				);
				$error = false;
				
				$value = array (
						'results' => $facilitiessee,
						'status' => false 
				);
				
				return $this->response->setOutput ( json_encode ( $value ) );
			}
			
			
			
			if ($json ['warning'] == null && $json ['warning'] == "") {
				
				$this->load->model('user/user');
				$this->load->model('user/user_group');
				$user_info = $this->model_user_user->getuserbynamenpass($username,$password);
				
				
				
				if(!empty($user_info)){
					$user_role_info = $this->model_user_user_group->getUserGroup($user_info['user_group_id']);
					
					$this->load->model ( 'api/encrypt' );
					$edevice_username = $this->model_api_encrypt->encrypt ( $this->config->get ( 'device_username' ) );
					$edevice_token = $this->model_api_encrypt->encrypt ( $this->config->get ( 'device_token' ) );
					
					
					$authorized_key = base64_encode($this->generate_uuid());
					$fdata = array();
					$fdata['facilities_id'] = $user_info ['user_id'];
					$fdata['authorized_key'] = $authorized_key;
					$fdata['activationKey'] = $user_info ['activationKey'];
					$fdata['session_id'] = $user_info ['facilities'];
					//$this->model_user_user->insertUsertoken($fdata);
									
					
			
					$this->data ['facilitiess'] [] = array (
						'user_id' => $user_info ['user_id'],
						'username' => $user_info ['username'],
						
						'firstname' => $user_info ['firstname'],
						'lastname' => $user_info ['lastname'],
						'email' => $user_info ['email'],
						'phone_number' => $user_info ['phone_number'],
						'facilities' => $user_info ['facilities'],
						'user_pin' => $user_info ['user_pin'],
						'activationKey' => $user_info ['activationKey'],
						'default_facilities_id' => $user_info ['default_facilities_id'],
						'default_highlighter_id' => $user_info ['default_highlighter_id'],
						'default_color' => $user_info ['default_color'],
						'customer_key' => $user_info ['customer_key'],
						'user_group_id' => $user_info ['user_group_id'],
						'name' => $user_role_info ['name'],
						'enable_requires_approval' => $user_role_info ['enable_requires_approval'],
						'inventory_permission' => $user_role_info ['inventory_permission'],
						'is_private' => $user_role_info ['is_private'],
						'share_notes' => $user_role_info ['share_notes'],
						'perpetual_task' => $user_role_info ['perpetual_task'],
						'device_username' => $edevice_username,
						'device_token' => $edevice_token,
						'authorized_key' => $authorized_key,
						
					);
					
					$error = true;
				}else{
					$this->data ['facilitiess'] [] = array (
						'warning' => "Incorrect username or password please try again"
					);
					$error = false;
				}
			} else {
				$this->data ['facilitiess'] [] = array (
						'warning' => $json ['warning'] 
				);
				$error = false;
			}
			$value = array (
					'results' => $this->data ['facilitiess'],
					'status' => $error ,
					'success' => 1
			);
			
			$this->response->setOutput ( json_encode ( $value ) );
		} catch ( Exception $e ) {
			
			$this->load->model ( 'activity/activity' );
			$activity_data2 = array (
					'data' => 'Error in appservices jsonuserLogin ' . $e->getMessage () 
			);
			$this->model_activity_activity->addActivity ( 'jsonuserLogin', $activity_data2 );
			
			
		}
	}
	

	public function jsonClassification() {
		
		try {
			
			$tags_id = $this->request->post['tags_id'];
			
			$this->load->model('notes/notes');
			$Categories = $this->model_notes_notes->getcaseCategories();
			
			$this->data['caseCategories'] = array();
			
			$this->data['caseCategories'][] = array(
				'label' => 'NoteActive',
				'imageIcon' => 'http://case.noteactive.com/assets/admin/dist/img/active_note.png',
				'link' =>  'http://case.noteactive.com/assets/admin/dist/img/active_note.png',
				'externalRedirect' => true,
				'hrefTargetType' => '_blank' // _blank|_self|_parent|_top|framename
			);
			
			foreach($Categories as $category){
				$cases1 = array();
				$cases = $this->model_notes_notes->getcases($category['case_category_id']);
				
				
				
				foreach($cases as $case){
					
					$casekeys = array();	
					$caseforms = array();
					$casetasks = array();
					$nitems = array();
					
					
					$datatask = array(
						'tasks_ids' => $case['tasks'],
						'tags_id' => $tags_id, 		
					);
					
					$this->load->model('task/tasktype');
					$casetask1s = $this->model_task_tasktype->gettasktype2($datatask);
					
					if(!empty($casetask1s)){
						foreach($casetask1s as $casetask){
							$casetask1s[] = array(
							  'label' => $casetask['tasktype_name'],
							  'faIcon' => $casetask['icon'],
							  'link' =>  $casetask['task_id'],
							);
						}
						
						$nitems[] = array(
							'label' => "TASK TYPE",
							'faIcon' => 'fas fa-allergies',
							//'link' => $this->url->link('case/clients/detail', '' . '&case_id=' . $case['case_id']. $url2, 'SSL'),
							'items' => $casetask1s,
						);
					}
					
					$datakey = array(
						'keyword_ids' => $case['keywords'],
						'tags_id' => $tags_id, 		
					);
					$this->load->model('setting/keywords');
					$casekey2s = $this->model_setting_keywords->getkeywords2($datakey);
					
					if(!empty($casekey2s)){
						foreach($casekey2s as $casekey){
							$casekeys[] = array(
							  'label' => $casekey['keyword_name'],
							  'faIcon' => 'fab fa-accusoft',
							  'parent' => $casekey['keyword_id'],
							  'link' => $casekey['keyword_id'],
							  
							);
						}
						
						$nitems[] = array(
							'label' => "KEYWORDS",
							'faIcon' => 'fas fa-allergies',
							//'link' => $this->url->link('case/clients/detail', '' . '&case_id=' . $case['case_id']. $url2, 'SSL'),
							'items' => $casekeys,
						);
					}
				
					$fdata = array(
						'forms_ids' => $case['forms'],
						'tags_id' => $tags_id, 
					);
					
					$this->load->model('form/form');
					$caseform2s = $this->model_form_form->getforms2($fdata);
					
					if(!empty($caseform2s)){
						foreach($caseform2s as $caseform){
							$caseforms[] = array(
							  'label' => $caseform['form_name'],
							  'faIcon' => 'fab fa-accusoft',
							 'link' =>  $caseform['forms_id'],
							);
						}
						
						$nitems[] = array(
							'label' => "FORMS",
							'faIcon' => 'fas fa-allergies',
							//'link' => $this->url->link('case/clients/detail', '' . '&case_id=' . $case['case_id']. $url2, 'SSL'),
							'items' => $caseforms,
						);
					}
					
					$cases1[] = array(
					 // 'case_id' => $case['case_id'],
					  'label' => $case['name'],
					  'faIcon' => $case['icon'],
					 // 'link' => $this->url->link('case/clients/detail', '' . '&case_id=' . $case['case_id']. $url2, 'SSL'),
					  'items' => $nitems,
					);
				
				}
				
				
				$this->data['caseCategories'][] = array(
				  //'case_category_id' => $category['case_category_id'],
				  'label' => $category['name'],
				  'faIcon' => $category['icon'],
				  //'link' => $this->url->link('case/clients/detail', '' . '&case_category_id=' . $category['case_category_id']. $url2, 'SSL'),
				  'items' => $cases1,
				);
				
				
			}
			
			$this->response->setOutput ( json_encode ( $this->data['caseCategories'] ) );
			
		} catch ( Exception $e ) {
			
			$this->load->model ( 'activity/activity' );
			$activity_data2 = array (
					'data' => 'Error in appservices jsonClassification ' . $e->getMessage () 
			);
			$this->model_activity_activity->addActivity ( 'app_jsonClassification', $activity_data2 );
		}
	}
	
	
	
	public function jsonclienttagform(){
		try{
			
		$this->data['facilitiess'] = array();
		$this->language->load('notes/notes');
		$this->load->model('setting/tags');
		$this->load->model('form/form');
		$this->load->model('notes/notes'); 
		
		
		
		$tags_id = $this->request->post['tags_id'];
		
		$tag_info = $this->model_setting_tags->getTag($tags_id);
		
		$name = $tag_info['emp_tag_id'].': '.$tag_info['emp_first_name'] .' '.$tag_info['emp_last_name'];
		
		
		
		if (isset($this->request->post['page'])) {
			$page = $this->request->post['page'];
		} else {
			$page = 1;
		}
		
		
		
		
		//$config_admin_limit1 = '5';
		//$this->config->get('config_front_limit');
		
		$config_admin_limit1 = $this->config->get('config_android_front_limit');
		
		if($config_admin_limit1 != null && $config_admin_limit1 != ""){
			$config_admin_limit = $config_admin_limit1;
		}else{
			$config_admin_limit = "25";
		}
		
		
		$data = array(
		'tags_id' => $tags_id,
		'start' => ($page - 1) * $config_admin_limit,
		'limit' => $config_admin_limit
		
		);
		
		$results = $this->model_form_form->gettagsforms($data);
		
		$form_total = $this->model_form_form->getTotalforms2($data);
		
		//$results = $this->model_form_form->getTotalforms2($tags_id);
    	
		foreach ($results as $allform) {
			
			$form_info = $this->model_form_form->getFormdata($allform['custom_form_type']);
			
			if($allform['notes_id'] > 0){
			$note_info = $this->model_notes_notes->getNote($allform['notes_id']);
			}
			
			if($allform['user_id'] != null && $allform['user_id'] != ""){
						$user_id = $allform['user_id'];
						$signature = $allform['signature'];
						$notes_pin = $allform['notes_pin'];
						$notes_type = $allform['notes_type'];
						
						if($allform['form_date_added'] != null && $allform['form_date_added'] != "0000-00-00 00:00:00"){
							$form_date_added = date($this->language->get('date_format_short_2'), strtotime($allform['form_date_added']));
						}else{
							$form_date_added = '';
						}
						
					}else{
						$user_id = $note_info['user_id'];
						$signature = $note_info['signature'];
						$notes_pin = $note_info['notes_pin'];
						$notes_type = $note_info['notes_type'];
						
						if($note_info['note_date'] != null && $note_info['note_date'] != "0000-00-00 00:00:00"){
							$form_date_added = date($this->language->get('date_format_short_2'), strtotime($note_info['note_date']));
						}else{
							$form_date_added = '';
						}
					}
			 
				$form_url =	str_replace('&amp;', '&', $this->url->link('services/form', '' . 'forms_id=' . $allform['forms_id']. '&facilities_id=' . $allform['facilities_id']. '&notes_id=' . $allform['notes_id']. '&forms_design_id=' . $allform['custom_form_type']. '&tags_id=' . $allform['tags_id']));
				
				
					
					if($allform['custom_form_type'] == '13' ){
						$print_url = str_replace('&amp;', '&', $this->url->link('form/form/printformfldjj', '' . 'forms_id=' . $allform['forms_id']. '&facilities_id=' . $allform['facilities_id']. '&notes_id=' . $allform['notes_id']. '&forms_design_id=' . $allform['custom_form_type'], true));
					}elseif($allform['custom_form_type'] == '9' ){
						//$print_url = str_replace('&amp;', '&', $this->url->link('form/form/printmonthly_firredrill', '' . 'forms_id=' . $allform['forms_id']. '&facilities_id=' . $allform['facilities_id']. '&notes_id=' . $allform['notes_id']. '&forms_design_id=' . $allform['custom_form_type'], true));
						$print_url = str_replace('&amp;', '&', $this->url->link('form/form/printform', '' . 'forms_id=' . $allform['forms_id']. '&facilities_id=' . $allform['facilities_id']. '&notes_id=' . $allform['notes_id']. '&forms_design_id=' . $allform['custom_form_type'], true));
					}elseif($allform['custom_form_type'] == '10' ){
						//$print_url = str_replace('&amp;', '&', $this->url->link('form/form/printincidentform', '' . 'forms_id=' . $allform['forms_id']. '&facilities_id=' . $allform['facilities_id']. '&notes_id=' . $allform['notes_id']. '&forms_design_id=' . $allform['custom_form_type'], true));
						$print_url = str_replace('&amp;', '&', $this->url->link('form/form/printform', '' . 'forms_id=' . $allform['forms_id']. '&facilities_id=' . $allform['facilities_id']. '&notes_id=' . $allform['notes_id']. '&forms_design_id=' . $allform['custom_form_type'], true));
					}elseif($allform['custom_form_type'] == '2' ){
						//$print_url = str_replace('&amp;', '&', $this->url->link('form/form/printintakeform', '' . 'forms_id=' . $allform['forms_id']. '&facilities_id=' . $allform['facilities_id']. '&notes_id=' . $allform['notes_id']. '&forms_design_id=' . $allform['custom_form_type'], true));
						$print_url = str_replace('&amp;', '&', $this->url->link('form/form/printform', '' . 'forms_id=' . $allform['forms_id']. '&facilities_id=' . $allform['facilities_id']. '&notes_id=' . $allform['notes_id']. '&forms_design_id=' . $allform['custom_form_type'], true));
					}elseif($allform['custom_form_type'] == '12' ){
						//$print_url = str_replace('&amp;', '&', $this->url->link('form/form/printintakeform', '' . 'forms_id=' . $allform['forms_id']. '&facilities_id=' . $allform['facilities_id']. '&notes_id=' . $allform['notes_id']. '&forms_design_id=' . $allform['custom_form_type'], true));
						$print_url = str_replace('&amp;', '&', $this->url->link('form/form/printform', '' . 'forms_id=' . $allform['forms_id']. '&facilities_id=' . $allform['facilities_id']. '&notes_id=' . $allform['notes_id']. '&forms_design_id=' . $allform['custom_form_type'], true));
					}else{
						$print_url = '';
					}
					
					
					//var_dump($allform);
					
				
				$this->data['facilitiess'][] = array(
							'form_type_id' => $allform['form_type_id'],
							'notes_id' => $allform['notes_id'],
							'form_type' => $allform['form_type'],
							'notes_type' => $notes_type,
							'user_id' => $user_id,
							'signature' => $signature,
							'notes_pin' => $notes_pin,
							'incident_number' => $allform['incident_number'],
							'form_date_added' => $form_date_added,
							'date_added2' => date('D F j, Y', strtotime($allform['date_added'])),
							'href'        => $form_url,
							'print_url'        => $print_url,
							'audio_attach_url' => '',
							'notes_by_task_id' => '',
							'locations_id' => '',
							'task_type' => '',
							'task_content' => '',
							'task_time' => '',
							'media_url' => '',
							'capacity' => '',
							'location_name' => '',
							'location_type' => '',
							'notes_task_type' => '',
							'tags_id' => '',
							'drug_name' => '',
							'dose' => '',
							'drug_type' => '',
							'quantity' =>'',
							'frequency' => '',
							'instructions' => '',
							'count' =>'',
							'createtask_by_group_id' => '',
							'task_comments' => '',
							'medication_file_upload' => '',
							'date_added' => '',
							'is_tag_url' => '',
							'is_census_url' => '',
							
				
				);
		}
		
		$value = array('results'=>$this->data['facilitiess'],'form_total' => $form_total,'status'=>true, 'client_name'=>$name);
		
		$this->response->setOutput(json_encode($value));
		
		
		}catch(Exception $e){
				$this->load->model('activity/activity');
				$activity_data2 = array(
					'data' => 'Error in apptask jsonclienttagform '.$e->getMessage(),
				);
				$this->model_activity_activity->addActivity('app_jsonclienttagform', $activity_data2);
		}
	
	}
	
	
	
	
	public function tagcasedashboard(){
		
		
		try{
			
			$this->data['facilitiess'] = array();
			$this->load->model('notes/caseservices'); 
			$this->load->model('setting/tags');
			
			
		/*Cases*/
		
			
		
		$this->load->model('facilities/facilities');
		$this->load->model('setting/timezone');
		$facilities_info = $this->model_facilities_facilities->getfacilities($this->request->post['facilities_id']);
		$timezone_info = $this->model_setting_timezone->gettimezone($facilities_info['timezone_id']);
		date_default_timezone_set($timezone_info['timezone_value']);
		
		
		
		
		
		$data = array(
		'emp_tag_id'=>$this->request->post['tags_id'],
		'facilities_id'=>$this->request->post['facilities_id'],
		'customer_key'=>$this->request->post['customer_key'],
		'note_date_from'=>$this->request->post['note_date_from'],
		'note_date_to'=>$this->request->post['note_date_to'],
		'activenote' => 'all',
		
		);
		
		

		$totalnotes = $this->model_notes_caseservices->totalNotes($data);
		$totalforms = $this->model_notes_caseservices->totalForms($data);
		$totalkeywords = $this->model_notes_caseservices->totalKeywords($data);
		
	
		
		$data1 = array(
		'emp_tag_id'=>$this->request->post['tags_id'],
		'facilities_id'=>$this->request->post['facilities_id'],
		'customer_key'=>$this->request->post['customer_key'],
		'note_date_from'=>$this->request->post['note_date_from'],
		'note_date_to'=>$this->request->post['note_date_to'],
		'activenote' => 37,
		);
		$emegencyDrill = $this->model_notes_caseservices->totalKeywords($data1);
		
		
		
		
		$data2 = array(
		'emp_tag_id'=>$this->request->post['tags_id'],
		'facilities_id'=>$this->request->post['facilities_id'],
		'customer_key'=>$this->request->post['customer_key'],
		'note_date_from'=>$this->request->post['note_date_from'],
		'note_date_to'=>$this->request->post['note_date_to'],
		'activenote' => 77,
		);
		$bedCheck = $this->model_notes_caseservices->totalKeywords($data2);
		
		
		
		$data3 = array(
		'emp_tag_id'=>$this->request->post['tags_id'],
		'facilities_id'=>$this->request->post['facilities_id'],
		'customer_key'=>$this->request->post['customer_key'],
		'note_date_from'=>$this->request->post['note_date_from'],
		'note_date_to'=>$this->request->post['note_date_to'],
		'activenote' => 106,
		);
		$wellbeing = $this->model_notes_caseservices->totalKeywords($data3);
		
		
		$data3 = array(
		'emp_tag_id'=>$this->request->post['tags_id'],
		'facilities_id'=>$this->request->post['facilities_id'],
		'customer_key'=>$this->request->post['customer_key'],
		'note_date_from'=>$this->request->post['note_date_from'],
		'note_date_to'=>$this->request->post['note_date_to'],
		'activenote' => 111,
		);
		$firewatch = $this->model_notes_caseservices->totalKeywords($data3);
		
		$data3 = array(
		'emp_tag_id'=>$this->request->post['tags_id'],
		'facilities_id'=>$this->request->post['facilities_id'],
		'customer_key'=>$this->request->post['customer_key'],
		'note_date_from'=>$this->request->post['note_date_from'],
		'note_date_to'=>$this->request->post['note_date_to'],
		'activenote' => 125,
		);
		$sucidewatch = $this->model_notes_caseservices->totalKeywords($data3);
		
		
		
		
		
		$data4 = array(
		'emp_tag_id'=>$this->request->post['tags_id'],
		'facilities_id'=>$this->request->post['facilities_id'],
		'customer_key'=>$this->request->post['customer_key'],
		'note_date_from'=>$this->request->post['note_date_from'],
		'note_date_to'=>$this->request->post['note_date_to'],
		'activenote' => 37,
		);
		$rounds = $this->model_notes_caseservices->totalKeywords($data4);
		
		
		$data5 = array(
		'emp_tag_id'=>$this->request->post['tags_id'],
		'facilities_id'=>$this->request->post['facilities_id'],
		'customer_key'=>$this->request->post['customer_key'],
		'note_date_from'=>$this->request->post['note_date_from'],
		'note_date_to'=>$this->request->post['note_date_to'],
		'activenote' => 172,
		);
		$classificationrounds = $this->model_notes_caseservices->totalKeywords($data5);
		
		
		$data6 = array(
		'emp_tag_id'=>$this->request->post['tags_id'],
		'facilities_id'=>$this->request->post['facilities_id'],
		'customer_key'=>$this->request->post['customer_key'],
		'note_date_from'=>$this->request->post['note_date_from'],
		'note_date_to'=>$this->request->post['note_date_to'],
		'activenote' => 155,
		);
		$incident = $this->model_notes_caseservices->totalKeywords($data6);
		
		$data6 = array(
		'emp_tag_id'=>$this->request->post['tags_id'],
		'facilities_id'=>$this->request->post['facilities_id'],
		'customer_key'=>$this->request->post['customer_key'],
		'note_date_from'=>$this->request->post['note_date_from'],
		'note_date_to'=>$this->request->post['note_date_to'],
		'activenote' => 74,
		);
		$rounds = $this->model_notes_caseservices->totalKeywords($data6);
		
		
		$data7 = array(
		'emp_tag_id'=>$this->request->post['tags_id'],
		'facilities_id'=>$this->request->post['facilities_id'],
		'customer_key'=>$this->request->post['customer_key'],
		'note_date_from'=>$this->request->post['note_date_from'],
		'note_date_to'=>$this->request->post['note_date_to'],
		'activenote' => 66,
		);
		$bakeAct = $this->model_notes_caseservices->totalKeywords($data7);
		
		
		$this->data['facilitiess'][] = array(
			'totalnotes'=>$totalnotes,
			'totalforms'=>$totalforms,
			'totalkeywords'=>$totalkeywords,
			'emegencyDrill'=>$emegencyDrill,
			'sucidewatch'=>$sucidewatch,
			'firewatch'=>$firewatch,
			'wellbeing'=>$wellbeing,
			'bedCheck'=>$bedCheck,
			'rounds'=>$rounds,
			'classificationrounds'=>$classificationrounds,
			'incident'=>$incident,
			'rounds'=>$rounds,
			'bakeAct'=>$bakeAct,
		
		);
		
		$value = array('results'=>$this->data['facilitiess']);
		
		$this->response->setOutput(json_encode($value));
		
		
		}catch(Exception $e){
				$this->load->model('activity/activity');
				$activity_data2 = array(
					'data' => 'Error in apptask jsonclienttagform '.$e->getMessage(),
				);
				$this->model_activity_activity->addActivity('app_jsonclienttagform', $activity_data2);
		}
		
		
	
	}
	
	
	
	public function activenote(){
		
		try{
			
			$this->data['facilitiess'] = array();
			$this->load->model('notes/caseservices'); 
			$this->load->model('setting/tags');
		
			$this->load->model('facilities/facilities');
			$this->load->model('setting/timezone');
			$facilities_info = $this->model_facilities_facilities->getfacilities($this->request->post['facilities_id']);
			$timezone_info = $this->model_setting_timezone->gettimezone($facilities_info['timezone_id']);
			date_default_timezone_set($timezone_info['timezone_value']);
		
		
			$unique_id = $facilities_info ['customer_key'];
		
			$this->load->model ( 'customer/customer' );
			
			$customer_info = $this->model_customer_customer->getcustomerid ( $unique_id );
			$activecustomer_id = $customer_info['activecustomer_id'];
			
		
			$data = array(
			'emp_tag_id'=>$this->request->post['tags_id'],
			'facilities_id'=>$this->request->post['facilities_id'],
			'note_date_from'=>$this->request->post['note_date_from'],
			'note_date_to'=>$this->request->post['note_date_to'],
			'customer_key'=> $activecustomer_id,
			);

			$allkeywords = $this->model_notes_caseservices->allKeywordsbyTotal($data);
				$keyname=array();
				$keycount=array();
				$keycolrcodes=array();
				
				foreach($allkeywords as $keyword){
					$keyname[] = $keyword['keyword_name'];
					$keycount[] = $keyword['keywordCount'];
				}
				
				$keynames21 = implode(',',$keyname);
				$keynamescount = implode(',',$keycount);

			$this->data['facilitiess'][] = array(
				'allkeywords'=>$allkeywords,
				'allkeynames'=>$keynames21,
				'allkeycounts'=>$keynamescount,
				'allcolorcode'=>['#f56954', '#00a65a', '#f39c12', '#00c0ef', '#3c8dbc', '#d2d6de','#d2d6e']
				
				
			);
			
			$value = array('results'=>$this->data['facilitiess']);
			
			$this->response->setOutput(json_encode($value));
		
		
		}catch(Exception $e){
				$this->load->model('activity/activity');
				$activity_data2 = array(
					'data' => 'Error in apptask jsonclienttagform '.$e->getMessage(),
				);
				$this->model_activity_activity->addActivity('app_jsonclienttagform', $activity_data2);
		}
		
		
	
	}
	
	
		public function barChartbyTotals(){
		
		
		try{
			
			$this->data['facilitiess'] = array();
			$this->load->model('notes/caseservices'); 
			$this->load->model('setting/tags');
		
			$this->load->model('facilities/facilities');
			$this->load->model('setting/timezone');
			$facilities_info = $this->model_facilities_facilities->getfacilities($this->request->post['facilities_id']);
			$timezone_info = $this->model_setting_timezone->gettimezone($facilities_info['timezone_id']);
			date_default_timezone_set($timezone_info['timezone_value']);
		
			$data = array(
			'emp_tag_id'=>$this->request->post['tags_id'],
			'facilities_id'=>$this->request->post['facilities_id'],
			'note_date_from'=>$this->request->post['note_date_from'],
			'note_date_to'=>$this->request->post['note_date_to'],
			'customer_key'=> $activecustomer_id,
			);
			
		

			$allnotes = $this->model_notes_caseservices->BarChartbyTotal($data);
					
			$this->data['facilitiess'] = array(
				'allnotes'=>$allnotes,
			);
			/*
			
			$this->data['facilitiess'] = array(
				[
				  'label'             => 'Digital Goods',
				  'backgroundColor'    => 'rgba(60,141,188,0.9)',
				  'backgroundColor'   =>'rgba(60,141,188,0.8)',
				  'backgroundColor'    => false,
				  'pointColor'          => '#3b8bba',
				  'pointStrokeColor'    => 'rgba(60,141,188,1)',
				  'pointStrokeColor'  => '#fff',
				  'pointHighlightStroke'=> 'rgba(60,141,188,1)',
				  'pointHighlightStroke'   => [28, 48, 40, 19, 86, 27, 90]
				],
				[
				  'label'               => 'Electronics',
				   'backgroundColor'     => 'rgba(210, 214, 222, 1)',
				  'borderColor '       => 'rgba(210, 214, 222, 1)',
				  'pointRadius'        => false,
				  'pointColor'          => 'rgba(210, 214, 222, 1)',
				  'pointStrokeColor '  => '#c1c7d1',
				  'pointHighlightFill ' => '#fff',
				  'pointHighlightStroke'=> 'rgba(220,220,220,1)',
				  'data'     => [65, 59, 80, 81, 56, 55, 40]
				],
			  );
			  */
	  
			
			//var_dump($this->data['facilitiess']);
			
			
			
			$value = array('results'=>$this->data['facilitiess']);
			
			$this->response->setOutput(json_encode($value));
		
		
		}catch(Exception $e){
				$this->load->model('activity/activity');
				$activity_data2 = array(
					'data' => 'Error in apptask jsonclienttagform '.$e->getMessage(),
				);
				$this->model_activity_activity->addActivity('app_jsonclienttagform', $activity_data2);
		}
		
		}
		
		
		public function getClientcustomform(){
		
			try{
				
			
			
			$this->load->model ( 'activity/activity' );
			$this->model_activity_activity->addActivitySave ( 'getClientcustomform', $this->request->post, 'request' );
				
			$this->data['facilitiess'] = array();
			$this->load->model('facilities/facilities');
			$this->load->model('notes/notes');
			$this->load->model('setting/tags');
			$this->load->model('api/encrypt');
			$cre_array = array();

			//$cre_array['phone_device_id'] = $this->request->post['phone_device_id'];
			//$cre_array['facilities_id'] = $this->request->post['facilities_id'];
			
		
		
			if(!empty($this->request->get['forms_design_id'])){
				
			
				$this->load->model('form/form');
				$fromdatas = $this->model_form_form->getFormdata($this->request->get['forms_design_id']);
				
				$this->data['layouts'] = explode(",",$fromdatas['form_layout']);
				
				$this->data['facilitiess'] = array(
					
					'fields' => $fromdatas['forms_fields'],
					'form_name' => $fromdatas['form_name'],
					'display_image' => $fromdatas['display_image'],
					'display_signature' => $fromdatas['display_signature'],
					'forms_setting' => $fromdatas['forms_setting'],
					'display_add_row' => $fromdatas['display_add_row'],
					'display_content_postion' => $fromdatas['display_content_postion'],
					'is_client_active' => $fromdatas['is_client_active'],
					'form_type' => $fromdatas['form_type'],
					'db_table_name' => $fromdatas['db_table_name'],
					'client_reqired' => $fromdatas['client_reqired'],
					'ddd' => $fromdatas['client_reqired'],
					
				);
				$error = true;
			
			}else{
				
				$this->data['facilitiess'][] = array(
					'warning'  => "Form not found",
				);
				$error = false;
			}
			
			$value = array('results'=>$this->data['facilitiess'],'status'=>$error);
			$this->response->setOutput(json_encode($value));
			return;
				
		
		}catch(Exception $e){
			
			$this->load->model('activity/activity');
			$activity_data2 = array(
				'data' => 'Error in appservices getClientcustomform '.$e->getMessage(),
			);
			$this->model_activity_activity->addActivity('app_getClientcustomform', $activity_data2);
		
		
		
		}   
		
	}
		
}
 
 