<?php

class Controllerlicenceactivation extends Controller {
	
	public function jsonLicenceactivation(){
		
		
	}
	
}

?>